ALTER TABLE mp_split_webhook_events
  ADD COLUMN lease_expires_at timestamptz(3);

UPDATE mp_split_webhook_events
SET lease_expires_at = updated_at + interval '5 minutes'
WHERE status = 'processing';

ALTER TABLE mp_split_webhook_events
  ADD CONSTRAINT mp_split_webhook_events_lease_state_check
  CHECK (
    (status = 'processing' AND lease_expires_at IS NOT NULL)
    OR (status <> 'processing' AND lease_expires_at IS NULL)
  );

DROP INDEX mp_split_webhook_events_retry_idx;

CREATE INDEX mp_split_webhook_events_retry_idx
  ON mp_split_webhook_events
    (status, lease_expires_at, updated_at, event_key);
