CREATE TABLE mp_split_connected_accounts (
  seller_id varchar(256) PRIMARY KEY,
  mercado_pago_user_id varchar(255) NOT NULL,
  encrypted_access_token text NOT NULL,
  encrypted_refresh_token text,
  access_token_expires_at timestamptz(3) NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz(3) NOT NULL,
  updated_at timestamptz(3) NOT NULL,
  CONSTRAINT mp_split_connected_accounts_mp_user_id_key
    UNIQUE (mercado_pago_user_id),
  CONSTRAINT mp_split_connected_accounts_seller_id_check
    CHECK (length(btrim(seller_id)) BETWEEN 1 AND 256),
  CONSTRAINT mp_split_connected_accounts_mp_user_id_check
    CHECK (length(btrim(mercado_pago_user_id)) BETWEEN 1 AND 255),
  CONSTRAINT mp_split_connected_accounts_access_token_check
    CHECK (length(encrypted_access_token) BETWEEN 1 AND 12000),
  CONSTRAINT mp_split_connected_accounts_refresh_token_check
    CHECK (
      encrypted_refresh_token IS NULL
      OR length(encrypted_refresh_token) BETWEEN 1 AND 12000
    )
);

CREATE INDEX mp_split_connected_accounts_enabled_idx
  ON mp_split_connected_accounts (enabled);

CREATE TABLE mp_split_oauth_states (
  state_hash varchar(128) PRIMARY KEY,
  seller_id varchar(256) NOT NULL,
  expires_at timestamptz(3) NOT NULL,
  created_at timestamptz(3) NOT NULL,
  consumed_at timestamptz(3),
  CONSTRAINT mp_split_oauth_states_state_hash_check
    CHECK (length(btrim(state_hash)) BETWEEN 1 AND 128),
  CONSTRAINT mp_split_oauth_states_seller_id_check
    CHECK (length(btrim(seller_id)) BETWEEN 1 AND 256),
  CONSTRAINT mp_split_oauth_states_expiration_check
    CHECK (expires_at > created_at),
  CONSTRAINT mp_split_oauth_states_consumed_at_check
    CHECK (consumed_at IS NULL OR consumed_at >= created_at)
);

CREATE INDEX mp_split_oauth_states_expires_at_idx
  ON mp_split_oauth_states (expires_at);

CREATE TABLE mp_split_webhook_events (
  event_key varchar(268) PRIMARY KEY,
  notification_id varchar(255) NOT NULL,
  notification_type varchar(100) NOT NULL,
  action varchar(150) NOT NULL,
  data_id varchar(255) NOT NULL,
  mercado_pago_user_id varchar(255) NOT NULL,
  status varchar(16) NOT NULL,
  attempts integer NOT NULL DEFAULT 1,
  last_error varchar(2048),
  received_at timestamptz(3) NOT NULL,
  updated_at timestamptz(3) NOT NULL,
  processed_at timestamptz(3),
  CONSTRAINT mp_split_webhook_events_notification_id_key
    UNIQUE (notification_id),
  CONSTRAINT mp_split_webhook_events_event_identity_check
    CHECK (event_key = 'notification:' || notification_id),
  CONSTRAINT mp_split_webhook_events_notification_type_check
    CHECK (length(btrim(notification_type)) BETWEEN 1 AND 100),
  CONSTRAINT mp_split_webhook_events_action_check
    CHECK (length(btrim(action)) BETWEEN 1 AND 150),
  CONSTRAINT mp_split_webhook_events_data_id_check
    CHECK (length(btrim(data_id)) BETWEEN 1 AND 255),
  CONSTRAINT mp_split_webhook_events_mp_user_id_check
    CHECK (length(btrim(mercado_pago_user_id)) BETWEEN 1 AND 255),
  CONSTRAINT mp_split_webhook_events_status_check
    CHECK (status IN ('processing', 'processed', 'failed')),
  CONSTRAINT mp_split_webhook_events_attempts_check
    CHECK (attempts > 0),
  CONSTRAINT mp_split_webhook_events_error_state_check
    CHECK (
      (status = 'failed' AND last_error IS NOT NULL)
      OR (status <> 'failed' AND last_error IS NULL)
    ),
  CONSTRAINT mp_split_webhook_events_processed_state_check
    CHECK (
      (status = 'processed' AND processed_at IS NOT NULL)
      OR (status <> 'processed' AND processed_at IS NULL)
    )
);

CREATE INDEX mp_split_webhook_events_retry_idx
  ON mp_split_webhook_events (status, updated_at, event_key);
