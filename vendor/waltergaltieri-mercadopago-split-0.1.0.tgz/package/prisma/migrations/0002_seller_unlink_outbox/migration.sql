CREATE TABLE mp_split_seller_unlink_events (
  event_id varchar(128) PRIMARY KEY,
  seller_id varchar(256) NOT NULL,
  mercado_pago_user_id varchar(255) NOT NULL,
  status varchar(16) NOT NULL,
  attempts integer NOT NULL DEFAULT 0,
  last_error varchar(2048),
  created_at timestamptz(3) NOT NULL,
  updated_at timestamptz(3) NOT NULL,
  available_at timestamptz(3) NOT NULL,
  lease_expires_at timestamptz(3),
  delivered_at timestamptz(3),
  CONSTRAINT mp_split_seller_unlink_events_event_id_check
    CHECK (length(btrim(event_id)) BETWEEN 1 AND 128),
  CONSTRAINT mp_split_seller_unlink_events_seller_id_check
    CHECK (length(btrim(seller_id)) BETWEEN 1 AND 256),
  CONSTRAINT mp_split_seller_unlink_events_mp_user_id_check
    CHECK (length(btrim(mercado_pago_user_id)) BETWEEN 1 AND 255),
  CONSTRAINT mp_split_seller_unlink_events_status_check
    CHECK (status IN ('pending', 'processing', 'failed', 'delivered')),
  CONSTRAINT mp_split_seller_unlink_events_attempts_check
    CHECK (attempts >= 0),
  CONSTRAINT mp_split_seller_unlink_events_error_state_check
    CHECK (
      (status = 'failed' AND last_error IS NOT NULL)
      OR (status <> 'failed' AND last_error IS NULL)
    ),
  CONSTRAINT mp_split_seller_unlink_events_lease_state_check
    CHECK (
      (status = 'processing' AND lease_expires_at IS NOT NULL)
      OR (status <> 'processing' AND lease_expires_at IS NULL)
    ),
  CONSTRAINT mp_split_seller_unlink_events_delivery_state_check
    CHECK (
      (status = 'delivered' AND delivered_at IS NOT NULL)
      OR (status <> 'delivered' AND delivered_at IS NULL)
    ),
  CONSTRAINT mp_split_seller_unlink_events_time_check
    CHECK (
      updated_at >= created_at
      AND available_at >= created_at
      AND (lease_expires_at IS NULL OR lease_expires_at >= updated_at)
      AND (delivered_at IS NULL OR delivered_at >= updated_at)
    )
);

CREATE INDEX mp_split_seller_unlink_events_retry_idx
  ON mp_split_seller_unlink_events
  (status, available_at, lease_expires_at, event_id);

CREATE INDEX mp_split_seller_unlink_events_seller_retry_idx
  ON mp_split_seller_unlink_events (seller_id, status, available_at);

CREATE INDEX mp_split_seller_unlink_events_mp_user_retry_idx
  ON mp_split_seller_unlink_events
  (mercado_pago_user_id, status, available_at);
