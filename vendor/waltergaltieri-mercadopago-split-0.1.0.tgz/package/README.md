# Mercado Pago Split para Node.js

Paquete TypeScript reutilizable para integrar **Split de Pagos 1:1 con Checkout Pro**. Vincula vendedores mediante OAuth, crea preferencias con `marketplace_fee`, cifra credenciales, valida webhooks y entrega callbacks normalizados sin incorporar reglas propias de la aplicación consumidora.

El paquete está preparado para publicarse de forma privada como `@waltergaltieri/mercadopago-split` mediante GitHub Packages. La publicación exige que la etiqueta coincida exactamente con la versión (`v0.1.0` para `0.1.0`), que el scope coincida con el propietario y que la metadata apunte a este repositorio.

## Alcance

Incluye:

- OAuth por vendedor, `state` opaco, expirable y de un solo uso.
- Renovación anticipada de access tokens.
- Cifrado AES-256-GCM antes de persistir tokens.
- Preferencias Checkout Pro con comisión fija `marketplace_fee`.
- Idempotencia obligatoria al crear preferencias.
- Validación HMAC de `x-signature` y `x-request-id`.
- Consulta del pago u orden comercial real antes del callback.
- Deduplicación persistente, leases y reintento seguro de webhooks.
- PostgreSQL mediante un adaptador Prisma autocontenido.
- Ayudantes opcionales para Express.

Esta versión no implementa Checkout API, `application_fee`, Split 1:N, UI ni reglas de negocio. Mercado Pago exige usar el access token OAuth del vendedor para Split 1:1; la comisión de Mercado Pago y las condiciones de reembolso siguen las reglas del producto. Consulta la [documentación oficial de Split 1:1](https://www.mercadopago.com.ar/developers/es/docs/split-payments/split-1-1/integration-configuration/integrate-marketplace).

## Arquitectura

La aplicación consumidora llama a una fábrica y conserva todas sus decisiones de negocio. El núcleo coordina tres módulos: OAuth administra la vinculación y renovación; Payments construye preferencias con el token del vendedor; Webhooks verifica la firma, reclama la notificación y consulta el recurso canónico antes de ejecutar un callback. Los tres comparten el contrato `SplitStorage`; `PrismaStorage` es su implementación PostgreSQL para producción.

Express es sólo un adaptador HTTP opcional. No forma parte del núcleo y puede reemplazarse por rutas de otro framework sin duplicar OAuth, pagos, seguridad o persistencia.

## Requisitos

- Node.js `^22.12` o `>=24`.
- PostgreSQL accesible desde la aplicación.
- Una aplicación de Mercado Pago configurada como Marketplace con Checkout Pro.
- Una Redirect URL OAuth y una URL de Webhooks públicas con HTTPS en producción.
- Un secreto de Webhooks y una clave aleatoria de cifrado de 32 bytes.

La Redirect URL enviada por la aplicación debe coincidir **exactamente** con la registrada en Mercado Pago. El paquete admite HTTP para esa URL sólo cuando el host es loopback (`localhost`, `127.0.0.1` o `[::1]`); usa HTTPS público fuera del desarrollo local. La [guía oficial de configuración](https://www.mercadopago.com.ar/developers/es/docs/split-payments/split-1-1/integration-configuration/create-configuration) explica cómo crear la aplicación Marketplace y obtener `client_id` y `client_secret`.

Las tres `backUrls` de Checkout Pro son distintas de la Redirect URL OAuth: `backUrls` exige HTTPS incluso en desarrollo y Mercado Pago desaconseja dominios locales. Usa un dominio de desarrollo accesible, según la [documentación oficial de URLs de retorno](https://www.mercadopago.com.ar/developers/es/docs/checkout-pro/configure-back-urls).

## Instalación privada desde GitHub Packages

Después de publicar la primera versión, configura el proyecto consumidor:

```ini
@waltergaltieri:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

```bash
npm install @waltergaltieri/mercadopago-split@0.1.0
npm install express
```

Para instalar un paquete privado, `NODE_AUTH_TOKEN` necesita permiso `read:packages`. No guardes el token en el repositorio. Consulta la [configuración oficial del registro npm de GitHub Packages](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry).

Mientras desarrollas dentro de este repositorio, el ejemplo usa `file:../..` y no requiere que el paquete esté publicado.

## Variables de entorno

| Variable | Uso |
| --- | --- |
| `MP_CLIENT_ID` | ID de la aplicación Marketplace. |
| `MP_CLIENT_SECRET` | Secreto de la aplicación. |
| `MP_WEBHOOK_SECRET` | Clave secreta configurada para Webhooks. |
| `MP_REDIRECT_URI` | Callback OAuth exacto, por ejemplo `https://api.example.com/oauth/callback`. |
| `MP_ENCRYPTION_KEY` | Clave base64 que decodifica a exactamente 32 bytes. |
| `DATABASE_URL` | Conexión PostgreSQL persistente. |

Genera la clave de cifrado una sola vez en un entorno seguro:

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('base64'))"
```

Guárdala inmediatamente en el gestor de secretos del proveedor. Perderla impide descifrar los tokens almacenados. No la imprimas en logs, CI ni paneles compartidos.

## Base de datos y migraciones

El paquete incluye sus propias tablas con prefijo `mp_split_` y un ejecutor de migraciones. Compila o instala el paquete y ejecuta una vez por entorno:

```bash
npx mercadopago-split migrate --database-url-env DATABASE_URL
```

La orden muestra únicamente nombres y resultados de migración; nunca imprime la cadena de conexión. Es segura al repetirse: las migraciones ya aplicadas se omiten y su checksum se verifica.

No ejecutes migraciones en cada request o cada arranque serverless. Hazlo como un paso de release contra una base respaldada.

## Uso recomendado

La fábrica compone OAuth, pagos, firma de webhooks y almacenamiento en una sola frontera segura:

```ts
import {
  createMercadoPagoSplit,
  type PaymentCallbacks,
} from '@waltergaltieri/mercadopago-split';
import { PrismaStorage } from '@waltergaltieri/mercadopago-split/prisma';

const storage = new PrismaStorage({ databaseUrl: process.env.DATABASE_URL! });

// Estas funciones pertenecen a tu aplicación y deben guardar eventId con una
// restricción única dentro de la misma transacción que el efecto de negocio.
const callbacks: PaymentCallbacks = {
  onPaymentApproved: async (notification) => {
    // La entrega es al menos una vez: deduplicar por notification.eventId.
    await applyPaymentOnce(notification.eventId, notification);
  },
  onPaymentRejected: async (notification) => {
    await applyPaymentOnce(notification.eventId, notification);
  },
  onSellerUnlinked: async (notification) => {
    await applyUnlinkOnce(notification.eventId, notification);
  },
};

const split = createMercadoPagoSplit({
  clientId: process.env.MP_CLIENT_ID!,
  clientSecret: process.env.MP_CLIENT_SECRET!,
  webhookSecret: process.env.MP_WEBHOOK_SECRET!,
  redirectUri: process.env.MP_REDIRECT_URI!,
  encryptionKey: process.env.MP_ENCRYPTION_KEY!,
  storage,
  callbacks,
});
```

En una aplicación real, valida la presencia de variables antes de construir la configuración; los `!` se usan aquí sólo para abreviar.

### Vincular un vendedor

Tu aplicación conserva su propio `sellerId`. El paquete guarda la relación con el usuario de Mercado Pago del lado servidor y nunca coloca ese identificador dentro de `state`.

```ts
const { url } = await split.oauth.createAuthorizationUrl({
  sellerId: 'seller-42',
});

// Redirigir el navegador a url.
```

En el callback HTTPS configurado en Mercado Pago:

```ts
const account = await split.oauth.completeAuthorization({ code, state });
console.log(account.sellerId, account.mercadoPagoUserId);
```

`state` se persiste como hash, vence y se consume una sola vez. Los tokens se guardan cifrados. `getValidAccessToken`, usado internamente, renueva credenciales antes del vencimiento sin crear una configuración global compartida del SDK.

También están disponibles:

```ts
await split.oauth.isSellerLinked('seller-42');
await split.oauth.unlinkSeller('seller-42');
```

### Crear una preferencia Split

Los importes se reciben como strings decimales con hasta dos posiciones. Esto evita redondeos accidentales antes del límite del SDK.

```ts
const preference = await split.payments.createPreference({
  sellerId: 'seller-42',
  externalReference: 'purchase-1001',
  idempotencyKey: 'purchase-1001-attempt-1',
  marketplaceFee: '10.00',
  items: [
    {
      id: 'product-1',
      title: 'Producto',
      currencyId: 'ARS',
      quantity: 1,
      unitPrice: '100.00',
    },
  ],
  backUrls: {
    success: 'https://app.example.com/payment/success',
    failure: 'https://app.example.com/payment/failure',
    pending: 'https://app.example.com/payment/pending',
  },
  autoReturn: 'approved',
  metadata: { source: 'api' },
  expiresAt: new Date(Date.now() + 30 * 60_000),
});

// preference.preferenceId, preference.initPoint, preference.sandboxInitPoint
```

La comisión es un monto fijo, debe ser no negativo y no puede superar el total. Todos los artículos deben usar la misma moneda. `idempotencyKey` debe ser estable para el mismo intento lógico y distinto para uno nuevo.

## Express

Instala Express en la aplicación consumidora y registra los adaptadores:

```ts
import express from 'express';
import {
  createOAuthAuthorizeHandler,
  createOAuthCallbackHandler,
  createWebhookHandler,
} from '@waltergaltieri/mercadopago-split/express';

const app = express();
app.use(express.json({ limit: '1mb' }));

app.get('/connect/:sellerId', createOAuthAuthorizeHandler(split.oauth));
app.get(
  '/oauth/callback',
  createOAuthCallbackHandler(split.oauth, {
    successRedirect: 'https://app.example.com/settings/payments',
  }),
);
app.post('/webhooks/mercadopago', createWebhookHandler(split.webhooks));
```

El handler OAuth admite `onComplete`, pero es una notificación **best effort**: se ejecuta después de persistir la vinculación, sus fallos se ignoran y no se reintenta. Úsalo sólo para tareas prescindibles. Si necesitas un efecto garantizado, diseña una operación durable propia a partir del estado ya persistido.

Para crear preferencias, agrega una ruta que llame a `split.payments.createPreference`. El [ejemplo Express + PostgreSQL](examples/express-postgres/README.md) contiene las cuatro rutas completas.

## Webhooks e idempotencia

Configura Webhooks, no IPN, y registra la URL HTTPS `/webhooks/mercadopago`. El adaptador Express conserva los headers, query y JSON necesarios para validar la firma antes de procesar.

En **Tus integraciones → Webhooks**, selecciona únicamente los tópicos que usa tu configuración:

- **Pagos (`payment`)**: necesario para los callbacks `onPayment*`.
- **Órdenes comerciales (`topic_merchant_order_wh`)**: actívalo sólo si configuraste `onMerchantOrder`.
- **Vinculación de aplicaciones (`mp-connect`)**: necesario para recibir la desvinculación OAuth y ejecutar `onSellerUnlinked`.

Estos nombres y tópicos corresponden a la [tabla oficial de notificaciones de Mercado Pago](https://www.mercadopago.com.ar/developers/es/docs/your-integrations/notifications).

`topic_merchant_order_wh` es el identificador que muestra actualmente la interfaz de Webhooks para órdenes comerciales. El paquete también acepta `merchant_order` únicamente para compatibilidad con envelopes Webhook firmados históricos que incluyen `x-signature` y `x-request-id`; no necesitas seleccionar ese identificador alternativo en la interfaz de Webhooks. El paquete no procesa IPN ni notificaciones sin firma.

Mercado Pago usa distintos identificadores con funciones diferentes:

- `body.id` es el identificador único de la **notificación**. El paquete crea `eventId` como `notification:<body.id>` y lo usa para deduplicar.
- `data.id` identifica el **recurso** (pago u orden comercial) que se consulta nuevamente en Mercado Pago.
- `x-request-id` forma parte de la validación de firma; no es la clave de deduplicación.

Los valores predeterminados de la fábrica son:

- `webhookMaxAgeSeconds`: desactivado (`undefined`). No rechaza una firma sólo por ser antigua, para admitir reintentos demorados de Mercado Pago.
- `webhookMaxFutureSkewSeconds`: `300`. Rechaza timestamps situados más de cinco minutos en el futuro.
- `webhookProcessingLeaseMs`: `300000` (cinco minutos). Reserva una notificación para una instancia mientras consulta el recurso y ejecuta el callback.
- `unlinkEventLeaseMs`: `300000` (cinco minutos). Reserva de igual forma la entrega durable de `onSellerUnlinked`.

Configura cada lease por encima de la peor duración esperable de su operación completa, incluyendo API de Mercado Pago, almacenamiento y callback. El paquete no renueva automáticamente estas leases ni ejecuta un heartbeat: el vencimiento queda fijo desde el reclamo. Si una operación tarda más que su lease, otra entrega puede reclamarla mientras el primer callback sigue activo y ambos pueden ejecutarse en paralelo; por eso los callbacks siguen siendo al menos una vez e idempotentes por `eventId`. Una lease demasiado larga reduce esa concurrencia accidental, pero demora la recuperación después de una caída. Ajusta ambos valores con métricas reales y margen, sin tratarlos como timeouts del callback.

Puedes definir `webhookMaxAgeSeconds` en segundos para reducir la ventana de replay de una solicitud válida capturada. El costo es que cualquier reintento auténtico más antiguo también será rechazado con 401. Sin límite de antigüedad, HTTPS y la deduplicación persistente por `body.id` protegen los reenvíos idénticos habituales, pero la ventana temporal queda abierta; elige el límite según la demora real de entrega que puedas tolerar. No desactives la deduplicación persistente aunque configures un límite temporal.

### Respuestas del adaptador Express

| Caso | HTTP | Respuesta |
| --- | ---: | --- |
| OAuth sin `sellerId`, `code` o `state` válido | 400 | `{"error":{"code":"INVALID_REQUEST"}}` |
| Intercambio OAuth rechazado | 400 | `{"error":{"code":"OAUTH_FAILED"}}` |
| Firma de webhook inválida | 401 | `{"error":{"code":"INVALID_SIGNATURE"}}` |
| Envelope de webhook inválido | 400 | `{"error":{"code":"INVALID_REQUEST"}}` |
| Body JSON ausente | 400 | `{"error":{"code":"JSON_BODY_REQUIRED"}}` |
| Body declarado o materializado mayor a 1 MiB | 413 | `{"error":{"code":"PAYLOAD_TOO_LARGE"}}` |
| Fallo inesperado, de callback o almacenamiento | 500 | `{"error":{"code":"INTERNAL_ERROR"}}` |
| `processed`, `duplicate` o `ignored` | 200 | `{"outcome":"..."}` |
| `in_progress` porque existe un lease activo | 503 | `{"outcome":"in_progress"}` |

Los códigos HTTP del adaptador son deliberadamente más reducidos que los códigos de error de la API TypeScript. No exponen diagnósticos internos.

Los callbacks son **al menos una vez**, no exactamente una vez. Un proceso puede caer después de ejecutar el callback y antes de marcarlo como completado; tras vencer el lease, la notificación se entregará otra vez. Toda escritura de negocio debe ser idempotente con `eventId` mediante una restricción única o transacción en la base de la aplicación.

El paquete no ejecuta un worker de reintento de webhooks en segundo plano. Si un callback falla, registra el intento como `failed`, responde 500 y la recuperación normal depende de una nueva entrega de Mercado Pago; esa entrega puede reclamar otra vez el mismo `body.id`. `storage.getRetryableWebhooks()` permite listar registros fallidos para monitoreo y alertas, pero no los reprocesa y la fábrica no expone un método que omita la firma. Si el proveedor deja de reenviar, reconcilia el recurso canónico mediante un proceso operativo separado e idempotente; no fabriques un objeto `VerifiedWebhook` ni invoques el handler con datos almacenados.

Callbacks disponibles:

- `onPaymentApproved`
- `onPaymentPending`
- `onPaymentInProcess`
- `onPaymentRejected`
- `onPaymentCancelled`
- `onPaymentRefunded`
- `onPaymentChargedBack`
- `onPaymentUnknown`
- `onMerchantOrder`
- `onSellerUnlinked`

Los callbacks de pago reciben, entre otros, `eventId`, `notificationId`, `sellerId`, `mercadoPagoUserId`, `paymentId`, `status`, `externalReference`, `transactionAmount`, `currencyId`, `marketplaceFee`, `metadata` y `occurredAt`. La desvinculación también es durable y al menos una vez; usa su `eventId`.

## Errores públicos

Todos extienden `MercadoPagoSplitError` y exponen un `code` estable sin incluir credenciales:

| Clase | Código |
| --- | --- |
| `ConfigurationError` | `CONFIGURATION_ERROR` |
| `ValidationError` | `VALIDATION_ERROR` |
| `SellerNotLinkedError` | `SELLER_NOT_LINKED` |
| `OAuthError` | `OAUTH_ERROR` |
| `InvalidWebhookSignatureError` | `INVALID_WEBHOOK_SIGNATURE` |
| `WebhookProcessingError` | `WEBHOOK_PROCESSING_ERROR` |
| `MercadoPagoApiError` | `MERCADO_PAGO_API_ERROR` |
| `StorageError` | `STORAGE_ERROR` |

No devuelvas `cause`, objetos del SDK ni errores internos completos al cliente. Registra sólo códigos seguros y un identificador de correlación propio.

## Seguridad y rotación

- Nunca registres access tokens, refresh tokens, claves de cifrado, secretos OAuth, firmas o cadenas PostgreSQL.
- Usa HTTPS público para OAuth y webhooks en producción. Sólo la Redirect URL OAuth admite HTTP loopback local; `backUrls` exige HTTPS incluso en desarrollo.
- Conserva `MP_ENCRYPTION_KEY` en un gestor de secretos y limita quién puede leerla.
- Respalda PostgreSQL y prueba la restauración antes de actualizar.
- Rota `client_secret` y el secreto de Webhooks coordinando primero Mercado Pago y luego el despliegue.
- Los tokens OAuth se renuevan automáticamente mientras exista un refresh token válido.

La versión 0.1 no automatiza la rotación de `MP_ENCRYPTION_KEY`. No reemplaces la clave directamente: los registros existentes dejarían de poder descifrarse. Prepara una migración controlada que, con escrituras detenidas y respaldo previo, descifre cada token con la clave anterior, lo vuelva a cifrar con la nueva y verifique el resultado antes de cambiar el secreto de ejecución.

## Flujo con cuentas de prueba

Antes de producción, usa credenciales y cuentas de prueba de Mercado Pago:

1. Aplica las migraciones en una base vacía y arranca la aplicación con secretos de prueba.
2. Abre `/connect/:sellerId`, autoriza con la cuenta vendedora y confirma la vuelta a `/oauth/callback`.
3. Comprueba en PostgreSQL que existen tokens cifrados, nunca valores OAuth legibles.
4. Crea una preferencia con una comisión visible y abre `sandboxInitPoint` cuando esté disponible.
5. Completa o simula el pago y comprueba que el callback normalizado recibe un `eventId`.
6. Reenvía la misma notificación y confirma que no repite el efecto idempotente.
7. Prueba la desvinculación y confirma el callback correspondiente.

No uses credenciales reales en fixtures, `.env.example`, capturas o comandos guardados. Una prueba automatizada exitosa no sustituye esta validación de extremo a extremo.

## Vercel, Railway y persistencia

PostgreSQL es la opción recomendada para producción porque OAuth, deduplicación, leases y reintentos necesitan estado durable compartido.

- **Railway:** el ejemplo Express puede ejecutarse como servicio Node de larga duración junto con PostgreSQL. Ejecuta la migración como paso separado del despliegue y configura todas las variables como secretos.
- **Vercel:** usa una base PostgreSQL externa persistente y adapta las rutas al modelo serverless del framework elegido. No crees `InMemorySplitStorage` por invocación. Reutiliza conexiones cuando el runtime lo permita, controla el límite de conexiones y ejecuta migraciones fuera de las funciones.
- **Cualquier plataforma con varias instancias:** todas deben apuntar a la misma base. El adaptador en memoria sirve solamente para pruebas o demostraciones de un único proceso.

## API avanzada

El entrypoint principal también exporta `OAuthManager`, `SplitPaymentClient`, `WebhookSignatureVerifier`, `WebhookHandler`, `TokenCipher` y sus puertos para composiciones personalizadas.

Prefiere `createMercadoPagoSplit`. Si compones webhooks manualmente, **verifica primero** con `WebhookSignatureVerifier` y entrega únicamente su resultado inmutable a `WebhookHandler`. No construyas ni fuerces por tipos un webhook “verificado”; omitir esa frontera permite procesar solicitudes no auténticas. Los puertos inyectables son para adaptadores controlados y deben mantener las mismas garantías de confidencialidad, atomicidad e identidad.

`OAuthManager.retrySellerUnlinkCallbacks()` existe como primitiva avanzada para drenar callbacks de desvinculación fallidos. La fábrica mantiene una superficie reducida y no la expone; si necesitas un worker dedicado, compón el manager conscientemente y ejecuta una sola política de reintentos por registro.

## Actualizaciones

Se usa versionado semántico:

- Patch: correcciones compatibles.
- Minor: capacidades nuevas compatibles.
- Major: cambios incompatibles de API, almacenamiento o comportamiento.

Para actualizar:

1. Lee [CHANGELOG.md](CHANGELOG.md) y las notas de migración.
2. Haz un respaldo de PostgreSQL.
3. Instala la versión exacta en un entorno de prueba.
4. Ejecuta `mercadopago-split migrate` una vez.
5. Ejecuta typecheck, pruebas y un flujo con cuentas de prueba.
6. Despliega sin editar migraciones históricas ya aplicadas.

## Desarrollo y validación

```bash
npm ci
npm run check
npm run package:verify
```

`package:verify` construye un tarball temporal, comprueba que no incluya fuentes, pruebas, ejemplos, archivos `.env` ni source maps, lo instala en un proyecto vacío e importa los entrypoints principal, Prisma y Express. CI ejecuta esa verificación en Node.js 22.12 y 24, siempre con PostgreSQL real mediante `TEST_DATABASE_URL`.

Las pruebas con credenciales de Mercado Pago son opcionales y nunca deben cargar secretos desde archivos versionados.

### Publicación privada

El workflow de publicación se activa sólo con etiquetas `v*`, repite las pruebas con PostgreSQL y publica en GitHub Packages mediante el `GITHUB_TOKEN` efímero del repositorio; no necesita un secreto npm para pull requests. Genera un único tarball después de que Node.js 22.12 y 24 hayan pasado, conserva su hash entre jobs y publica esos mismos bytes con los lifecycle scripts desactivados. El job que recibe el token no descarga el repositorio, no instala dependencias y no ejecuta código del paquete.

Antes de crear la primera etiqueta:

1. Decide si el paquete seguirá siendo propietario (`"license": "UNLICENSED"`) o agrega una licencia con el titular y año correctos.
2. Crea la etiqueta sólo después de integrar CI; el tag debe ser exactamente `v` seguido de la versión del paquete.
3. En **Settings → Rules → Rulesets**, crea un tag ruleset activo para `v*` que restrinja creación, actualización y eliminación de tags a los responsables del release.
4. En **Settings → Environments**, crea el environment `release`, limita sus deployment tags a `v*` y configura revisores requeridos. El job con `packages: write` queda detenido hasta esa aprobación.

El workflow también exige que el commit etiquetado pertenezca al historial de la rama predeterminada configurada en GitHub; no supone que esa rama se llame `main`.

GitHub Packages usa `GITHUB_TOKEN` con permiso `packages: write`; el trusted publishing OIDC de npmjs no interviene en este flujo privado. Si en el futuro se cambia el destino a npmjs, configura allí un trusted publisher para el repositorio/workflow reales y revisa visibilidad, licencia, `publishConfig` y procedencia antes de publicar.

Para ejecutar el ejemplo local, sigue [examples/express-postgres/README.md](examples/express-postgres/README.md).
