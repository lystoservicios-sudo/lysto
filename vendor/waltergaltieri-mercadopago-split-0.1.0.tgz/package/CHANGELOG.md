# Changelog

Los cambios relevantes de este paquete se documentan en este archivo. El proyecto sigue versionado semántico.

## [0.1.0] - 2026-09-02

### Release status

La versión 0.1.0 está preparada en `waltergaltieri/mercadopago-split-node`, pero **no fue publicada**. Antes de publicarla se debe configurar el entorno protegido de GitHub Packages y completar la validación con cuentas de prueba de `docs/test-account-checklist.md`.

### Added

- Flujo OAuth de vendedores con renovación de credenciales y tokens cifrados.
- Preferencias Checkout Pro Split 1:1 idempotentes.
- Webhooks firmados, consulta canónica, deduplicación persistente y callbacks normalizados.
- Adaptadores para PostgreSQL/Prisma y Express.
- Migraciones versionadas para vinculaciones OAuth, procesamiento de webhooks y outbox de desvinculación.
- Ejemplo independiente con Express y PostgreSQL.
- Documentación de integración, despliegue y checklist de validación con cuentas de prueba.

### Security

- Cifrado AES-256-GCM con contexto de vendedor y tipo de token.
- Verificación de firmas, límites de antigüedad y tamaño, URLs restringidas y errores redactados.
- Leases y transiciones atómicas para evitar procesamiento concurrente o desvinculaciones obsoletas.

### CI and release

- Matriz de Node.js 22.12 y 24 con PostgreSQL real en CI.
- Validación del contenido, identidad y hash del artefacto antes de publicar en GitHub Packages.
- Flujo de publicación por tags protegidos y entorno `release` con aprobación.
